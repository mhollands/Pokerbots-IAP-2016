python Player.py "$@"
